#!/bin/bash

# ------------------------------------
# backup_full.sh
# Script de backup con validaciones
# ------------------------------------

# Mostrar ayuda
mostrar_ayuda() {

    echo -e "\e[1;36m==============================================\e[0m"
    echo -e "\e[1;32m           AYUDA DEL SCRIPT DE BACKUP        \e[0m"
    echo -e "\e[1;36m==============================================\e[0m"
    echo
    echo -e "\e[1;33mUso:\e[0m"
    echo -e "   \e[32m$0 <origen> <destino>\e[0m"
    echo
    echo -e "\e[1;33mDescripción:\e[0m"
    echo "   Este script genera un archivo .tar.gz con fecha en formato YYYYMMDD"
    echo "   y lo guarda en el directorio destino indicado."
    echo
    echo -e "\e[1;33mEjemplos:\e[0m"
    echo -e "   Backup de logs del sistema:"
    echo -e "      \e[32m$0 /var/log /backup_dir\e[0m"
    echo
    echo -e "   Backup de tu carpeta web:"
    echo -e "      \e[32m$0 /www_dir /backup_dir\e[0m"
    echo
    echo -e "\e[1;33mOpciones:\e[0m"
    echo -e "   \e[32m-help\e[0m     Muestra esta ayuda"
    echo -e "   \e[32m--help\e[0m    Igual que -help"
    echo -e "   \e[32m-h\e[0m        Versión corta"
    echo
    echo -e "\e[1;33mNotas importantes:\e[0m"
    echo "   • El directorio de origen debe existir."
    echo "   • El directorio destino debe estar montado (no solo existir)."
    echo "   • El archivo generado incluye la fecha automáticamente."
    echo
    echo -e "\e[1;36m==============================================\e[0m"
    echo -e "\e[1;32m                FIN DE LA AYUDA               \e[0m"
    echo -e "\e[1;36m==============================================\e[0m"

    exit 0
}

# Si la primera opción es ayuda, mostrarla
case "$1" in
  -h|--help|-help|"")
    mostrar_ayuda
    ;;
esac

# Asignación correcta de parámetros
ORIGEN="$1"
DESTINO="$2"

# Validar argumentos
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
    echo "Error: Debe indicar origen y destino."
    echo "Use '-help' para más información."
    exit 1
fi

# Validar que el origen existe
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe."
    exit 2
fi

# Validar que el destino existe y está montado
if ! mountpoint -q "$DESTINO"; then
    echo "Error: El destino '$DESTINO' no está montado o no existe."
    exit 3
fi

# Crear nombre del archivo con fecha YYYYMMDD
FECHA=$(date +"%Y%m%d")
NOMBRE_ARCHIVO="$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz"

# Ruta completa del backup
ARCHIVO_SALIDA="$DESTINO/$NOMBRE_ARCHIVO"

echo "Generando backup..."
tar -czf "$ARCHIVO_SALIDA" "$ORIGEN"

if [[ $? -eq 0 ]]; then
    echo "Backup generado correctamente: $ARCHIVO_SALIDA"
    exit 0
else
    echo "Error al generar el backup."
    exit 4
fi
